
import { EnergyDataPoint, Insight, LeaderboardEntry } from './types';

export const COLORS = {
  primary: '#3b82f6',
  secondary: '#10b981',
  danger: '#ef4444',
  warning: '#f59e0b',
  info: '#0ea5e9',
};

// Explicitly generate data with waste patterns
export const MOCK_ENERGY_DATA: EnergyDataPoint[] = Array.from({ length: 48 }).map((_, i) => {
  const timestamp = new Date(Date.now() - (47 - i) * 1800000);
  const hour = timestamp.getHours();
  
  // Logic: 9 AM to 6 PM are office hours
  const isOfficeHours = hour >= 9 && hour <= 18;
  
  // Force occupancy to 0 outside office hours for 80% of points
  const occupancy = isOfficeHours ? (Math.random() > 0.1 ? 1 : 0) : (Math.random() > 0.9 ? 1 : 0);
  
  // Waste Logic: If occupancy is 0 but it's just after office hours (6 PM - 9 PM), 
  // create high consumption (The "Post-Occupancy" leak)
  let consumption = 0;
  if (occupancy === 1) {
    consumption = 30 + Math.random() * 20; // Normal load
  } else {
    // Anomalous waste: High usage when occupancy is 0
    if (hour > 18 && hour < 22) {
      consumption = 25 + Math.random() * 15; // Waste!
    } else {
      consumption = 5 + Math.random() * 5; // Normal base load
    }
  }

  return {
    timestamp: timestamp.toISOString(),
    consumption,
    occupancy,
    floor: `Floor ${Math.floor(i / 10) + 1}`,
    type: ['HVAC', 'Lighting', 'Equipment'][Math.floor(Math.random() * 3)] as any,
  };
});

export const INITIAL_INSIGHTS: Insight[] = [
  {
    id: '1',
    title: 'Post-Occupancy Waste',
    description: 'Floor 3 HVAC remains at 70% load despite zero occupancy detected after 7:00 PM.',
    impact: '₹420/day',
    priority: 'High',
    category: 'Waste',
    timestamp: new Date().toISOString(),
  }
];

export const MOCK_LEADERBOARD: LeaderboardEntry[] = [
  { id: 'u1', name: 'Operations Team', points: 1450, rank: 1, savings: 5200 },
  { id: 'u2', name: 'IT Cluster', points: 1200, rank: 2, savings: 4100 },
  { id: 'u3', name: 'Marketing Hub', points: 850, rank: 3, savings: 1900 },
];
