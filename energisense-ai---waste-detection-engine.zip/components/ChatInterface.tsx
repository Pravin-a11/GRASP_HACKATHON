
import React, { useState, useRef, useEffect } from 'react';
import { Send, Mic, MicOff, Bot, User, BrainCircuit, Sparkles } from 'lucide-react';
import { chatWithEnergyAdvisor } from '../services/geminiService';
import { EnergyDataPoint } from '../types';

interface ChatInterfaceProps {
  energyData: EnergyDataPoint[];
}

const ChatInterface: React.FC<ChatInterfaceProps> = ({ energyData }) => {
  const [messages, setMessages] = useState<{ role: 'bot' | 'user'; text: string; thinking?: boolean }[]>([
    { role: 'bot', text: 'Neural analysis initialized. How can I assist with your energy optimization today?' }
  ]);
  const [input, setInput] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async (text?: string) => {
    const messageText = text || input;
    if (!messageText.trim()) return;

    setMessages(prev => [...prev, { role: 'user', text: messageText }]);
    setInput('');
    setLoading(true);

    try {
      const response = await chatWithEnergyAdvisor(messageText, energyData);
      setMessages(prev => [...prev, { role: 'bot', text: response || "Analysis timed out. Please retry." }]);
    } catch (error) {
      setMessages(prev => [...prev, { role: 'bot', text: 'Error in neural bridge.' }]);
    } finally {
      setLoading(false);
    }
  };

  const toggleVoice = () => {
    if (!('webkitSpeechRecognition' in window)) {
      alert("Voice recognition is not supported in this browser.");
      return;
    }

    const recognition = new (window as any).webkitSpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;

    if (!isRecording) {
      setIsRecording(true);
      recognition.start();
      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        handleSend(transcript);
        setIsRecording(false);
      };
      recognition.onerror = () => setIsRecording(false);
      recognition.onend = () => setIsRecording(false);
    } else {
      setIsRecording(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-50 dark:bg-slate-900 overflow-hidden">
      <div className="flex-1 p-6 overflow-y-auto space-y-6 scroll-smooth custom-scrollbar" ref={scrollRef}>
        {messages.map((msg, idx) => (
          <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[85%] p-5 rounded-3xl flex gap-4 ${
              msg.role === 'user' 
              ? 'bg-primary text-white rounded-tr-none shadow-xl shadow-primary/10' 
              : 'bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 shadow-sm border border-slate-200 dark:border-slate-700 rounded-tl-none'
            }`}>
              <div className="shrink-0 mt-1">
                {msg.role === 'bot' ? <Bot size={18} className="text-primary" /> : <User size={18} />}
              </div>
              <div>
                <p className="text-sm leading-relaxed font-medium">{msg.text}</p>
              </div>
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="bg-white dark:bg-slate-800 p-5 rounded-3xl shadow-sm border border-slate-200 dark:border-slate-700 rounded-tl-none">
              <div className="flex items-center gap-3">
                <BrainCircuit className="text-primary animate-pulse" size={18} />
                <span className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">AI Reasoning...</span>
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="p-6 bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800">
        <div className="flex gap-3">
          <button 
            onClick={toggleVoice}
            className={`p-4 rounded-2xl transition-all ${
              isRecording ? 'bg-red-500 text-white animate-pulse' : 'bg-slate-100 dark:bg-slate-800 text-slate-400 hover:text-primary'
            }`}
          >
            {isRecording ? <MicOff size={20} /> : <Mic size={20} />}
          </button>
          <div className="flex-1 relative">
            <input 
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Ask for an energy audit..."
              className="w-full bg-slate-100 dark:bg-slate-800 border-none rounded-2xl px-6 py-4 text-sm font-medium focus:ring-2 focus:ring-primary outline-none text-slate-900 dark:text-white transition-all pr-12"
            />
            <button 
              onClick={() => handleSend()}
              className="absolute right-3 top-1/2 -translate-y-1/2 p-2 text-primary hover:scale-110 transition-transform"
            >
              <Send size={20} />
            </button>
          </div>
        </div>
        <div className="mt-4 flex items-center justify-center gap-2 text-[9px] font-black text-slate-400 uppercase tracking-widest">
          <Sparkles size={10} className="text-primary" />
          Powered by Gemini 3.1 Neural Core
        </div>
      </div>
    </div>
  );
};

export default ChatInterface;
