
import React, { useState } from 'react';
import { 
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  Legend, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar,
  AreaChart, Area, PieChart, Pie, Cell
} from 'recharts';
import { BarChart3, Download, Table, FileSpreadsheet, Activity, PieChart as PieIcon } from 'lucide-react';
import { EnergyDataPoint } from '../types';

interface AnalyticsViewProps {
  data: EnergyDataPoint[];
}

const AnalyticsView: React.FC<AnalyticsViewProps> = ({ data }) => {
  const [activeChart, setActiveChart] = useState<'standard' | 'tnea'>('tnea');

  const lineData = data.slice(-24).map(d => ({
    time: new Date(d.timestamp).toLocaleTimeString([], { hour: '2-digit' }),
    consumption: d.consumption,
    efficiency: Math.max(0, 100 - (d.consumption / (d.occupancy === 0 ? 5 : 20) * 10)),
    waste: d.occupancy === 0 ? d.consumption : 0
  }));

  const typeData = [
    { name: 'HVAC', value: data.filter(d => d.type === 'HVAC').reduce((a, b) => a + b.consumption, 0) },
    { name: 'Lighting', value: data.filter(d => d.type === 'Lighting').reduce((a, b) => a + b.consumption, 0) },
    { name: 'Equipment', value: data.filter(d => d.type === 'Equipment').reduce((a, b) => a + b.consumption, 0) },
    { name: 'Phantom', value: data.filter(d => d.type === 'Phantom' || (d.occupancy === 0 && d.consumption > 5)).reduce((a, b) => a + b.consumption, 0) },
  ];

  const TYPE_COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444'];

  const tneaData = [
    { metric: 'Network Latency', value: 85, target: 95 },
    { metric: 'Energy Sink', value: 72, target: 90 },
    { metric: 'Signal Noise', value: 45, target: 20 },
    { metric: 'Load Factor', value: 88, target: 80 },
    { metric: 'Thermal Loss', value: 30, target: 25 },
  ];

  const exportCSV = () => {
    const headers = ['Timestamp', 'Consumption_kWh', 'Occupancy', 'Floor', 'Type'];
    const rows = data.map(d => [d.timestamp, d.consumption, d.occupancy, d.floor, d.type]);
    const csvContent = "data:text/csv;charset=utf-8," + 
      [headers, ...rows].map(e => e.join(",")).join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "energisense_audit_data.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-black">Deep Neural Analytics</h2>
          <p className="text-slate-500 dark:text-slate-400 text-sm font-medium uppercase tracking-widest text-[10px] mt-1">Multi-signal correlation engine active</p>
        </div>
        <div className="flex bg-slate-100 dark:bg-slate-800 p-1.5 rounded-2xl border border-slate-200 dark:border-slate-700">
           <button onClick={() => setActiveChart('standard')} className={`px-6 py-2 text-[10px] font-black uppercase rounded-xl transition-all ${activeChart === 'standard' ? 'bg-white dark:bg-slate-700 shadow-sm text-primary' : 'text-slate-500'}`}>Standard Load</button>
           <button onClick={() => setActiveChart('tnea')} className={`px-6 py-2 text-[10px] font-black uppercase rounded-xl transition-all ${activeChart === 'tnea' ? 'bg-white dark:bg-slate-700 shadow-sm text-primary' : 'text-slate-500'}`}>TNEA Performance</button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white dark:bg-slate-900 p-8 rounded-[2rem] border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex items-center justify-between mb-8">
            <h3 className="font-black text-xl tracking-tight flex items-center gap-3">
              <Activity className="text-primary" size={24} />
              {activeChart === 'tnea' ? 'Performance Spectrum' : 'Load Variance'}
            </h3>
            <button 
              onClick={() => window.print()}
              className="flex items-center gap-2 px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 rounded-xl text-[10px] font-black uppercase hover:bg-slate-200 transition-all no-print"
            >
              <Download size={14} /> Export Audit PDF
            </button>
          </div>
          
          <div className="h-[400px]">
            <ResponsiveContainer width="100%" height="100%">
              {activeChart === 'tnea' ? (
                <RadarChart cx="50%" cy="50%" outerRadius="80%" data={tneaData}>
                  <PolarGrid stroke="rgba(148, 163, 184, 0.1)" />
                  <PolarAngleAxis dataKey="metric" tick={{fontSize: 10, fill: '#64748b', fontWeight: 'bold'}} />
                  <Radar name="Current" dataKey="value" stroke="var(--p-color)" fill="var(--p-color)" fillOpacity={0.5} strokeWidth={3} />
                  <Radar name="Target" dataKey="target" stroke="#94a3b8" fill="transparent" strokeWidth={1} strokeDasharray="4 4" />
                  <Tooltip contentStyle={{ borderRadius: '20px', border: 'none', backgroundColor: '#0f172a', color: 'white' }} />
                </RadarChart>
              ) : (
                <AreaChart data={lineData}>
                  <defs>
                    <linearGradient id="anaGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="var(--p-color)" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="var(--p-color)" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(148, 163, 184, 0.05)" />
                  <XAxis dataKey="time" axisLine={false} tickLine={false} tick={{fontSize: 10, fill: '#94a3b8', fontWeight: 'bold'}} />
                  <YAxis axisLine={false} tickLine={false} tick={{fontSize: 10, fill: '#94a3b8', fontWeight: 'bold'}} />
                  <Tooltip />
                  <Area type="monotone" dataKey="efficiency" stroke="var(--p-color)" strokeWidth={4} fill="url(#anaGrad)" />
                  <Line type="monotone" dataKey="waste" stroke="#ef4444" strokeWidth={2} dot={false} strokeDasharray="3 3" />
                </AreaChart>
              )}
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-slate-900 p-8 rounded-[2.5rem] flex flex-col justify-between text-white overflow-hidden relative shadow-2xl">
          <div className="absolute top-0 right-0 p-8 opacity-5">
            <PieIcon size={150} />
          </div>
          <div className="relative z-10">
            <h3 className="text-xl font-black tracking-tight mb-8">Consumption Split</h3>
            <div className="h-[250px] mb-8">
               <ResponsiveContainer width="100%" height="100%">
                 <PieChart>
                    <Pie
                      data={typeData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={8}
                      dataKey="value"
                    >
                      {typeData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={TYPE_COLORS[index % TYPE_COLORS.length]} stroke="none" />
                      ))}
                    </Pie>
                    <Tooltip contentStyle={{ borderRadius: '15px', backgroundColor: '#1e293b', border: 'none' }} />
                 </PieChart>
               </ResponsiveContainer>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {typeData.map((t, i) => (
                <div key={i} className="flex items-center gap-2 p-3 bg-white/5 rounded-2xl border border-white/5">
                  <div className="w-2.5 h-2.5 rounded-full" style={{backgroundColor: TYPE_COLORS[i]}} />
                  <span className="text-[10px] font-black uppercase tracking-widest opacity-80">{t.name}</span>
                </div>
              ))}
            </div>
          </div>
          <button 
            onClick={exportCSV} 
            className="mt-8 w-full py-4 bg-primary text-white rounded-2xl font-black uppercase tracking-widest text-xs flex items-center justify-center gap-3 hover:scale-[1.02] transition-all no-print shadow-xl shadow-primary/20"
          >
            <FileSpreadsheet size={18} />
            Full Laboratory Export (Excel/CSV)
          </button>
        </div>
      </div>
    </div>
  );
};

export default AnalyticsView;
