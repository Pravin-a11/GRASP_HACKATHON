
import React from 'react';
import { 
  LayoutDashboard, 
  BarChart3, 
  ShieldCheck, 
  Zap, 
  Trophy, 
  Settings, 
  LogOut,
  Database,
  Smartphone,
  BrainCircuit
} from 'lucide-react';
import { UserRole } from '../types';

interface SidebarProps {
  currentRole: UserRole;
  onNavigate: (view: string) => void;
  onLogout: () => void;
  activeView: string;
}

const Sidebar: React.FC<SidebarProps> = ({ currentRole, onNavigate, onLogout, activeView }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, roles: [UserRole.USER, UserRole.ADMIN] },
    { id: 'waste-engine', label: 'Waste Engine', icon: BrainCircuit, roles: [UserRole.USER, UserRole.ADMIN] },
    { id: 'analytics', label: 'Analytics', icon: BarChart3, roles: [UserRole.USER, UserRole.ADMIN] },
    { id: 'gamification', label: 'Eco-Rewards', icon: Trophy, roles: [UserRole.USER] },
    { id: 'admin-portal', label: 'Data Lab', icon: Database, roles: [UserRole.ADMIN] },
    { id: 'security', label: 'Security', icon: ShieldCheck, roles: [UserRole.ADMIN] },
    { id: 'mobile', label: 'Mobile Sync', icon: Smartphone, roles: [UserRole.USER, UserRole.ADMIN] },
  ];

  return (
    <div className="w-72 h-full bg-slate-900 text-white flex flex-col p-6 border-r border-slate-800 no-print shadow-2xl z-20">
      <div className="flex items-center gap-4 mb-12 px-2 cursor-pointer transition-transform hover:scale-[1.02]" onClick={() => onNavigate('dashboard')}>
        <div className="p-3 bg-primary rounded-2xl shadow-2xl shadow-primary/30">
          <Zap size={28} className="text-white fill-white/20" />
        </div>
        <div>
          <span className="font-black text-xl tracking-tighter block leading-none">EnergiSense</span>
          <span className="text-[10px] uppercase tracking-[0.4em] font-black text-slate-500 mt-1 block">NEURAL CORE</span>
        </div>
      </div>

      <nav className="flex-1 space-y-2">
        {menuItems
          .filter(item => item.roles.includes(currentRole))
          .map((item) => (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`w-full flex items-center gap-4 px-5 py-4 rounded-2xl transition-all duration-300 group ${
                activeView === item.id 
                ? 'bg-primary text-white shadow-2xl shadow-primary/20 scale-[1.02]' 
                : 'text-slate-400 hover:bg-slate-800/50 hover:text-slate-200'
              }`}
            >
              <item.icon size={22} className={`transition-transform duration-300 ${activeView === item.id ? 'scale-110' : 'group-hover:scale-110'}`} />
              <span className="font-black text-sm uppercase tracking-widest">{item.label}</span>
            </button>
          ))}
      </nav>

      <div className="mt-auto pt-8 border-t border-slate-800 space-y-2">
        <button 
          onClick={() => onNavigate('settings')}
          className={`w-full flex items-center gap-4 px-5 py-4 rounded-2xl transition-all group ${
            activeView === 'settings' 
            ? 'bg-slate-700 text-white shadow-xl' 
            : 'text-slate-500 hover:text-slate-200'
          }`}
        >
          <Settings size={22} className="group-hover:rotate-45 transition-transform" />
          <span className="text-sm font-black uppercase tracking-widest">System Settings</span>
        </button>
        <button 
          onClick={onLogout}
          className="w-full flex items-center gap-4 px-5 py-4 text-red-400/70 hover:text-red-400 transition-all group rounded-2xl hover:bg-red-500/10"
        >
          <LogOut size={22} className="group-hover:-translate-x-1 transition-transform" />
          <span className="text-sm font-black uppercase tracking-widest">Exit Terminal</span>
        </button>
      </div>
    </div>
  );
};

export default Sidebar;
