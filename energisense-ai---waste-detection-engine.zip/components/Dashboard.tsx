
import React, { useState } from 'react';
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar, Cell, LineChart, Line
} from 'recharts';
import { 
  TrendingUp, Zap, Clock, AlertTriangle, Download, Info, Award, ShieldCheck, RefreshCw, BarChart4, Leaf,
  // Added missing imports for Bot and CheckCircle2
  Bot, CheckCircle2
} from 'lucide-react';
import { EnergyDataPoint, Insight, LeaderboardEntry } from '../types';
import { COLORS, MOCK_LEADERBOARD } from '../constants';

interface DashboardProps {
  data: EnergyDataPoint[];
  insights: Insight[];
  userPoints: number;
  onExport: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ data, insights, userPoints, onExport }) => {
  const [activeTab, setActiveTab] = useState<'realtime' | 'seasonal'>('realtime');

  const chartData = data.slice(-24).map(d => ({
    time: new Date(d.timestamp).toLocaleTimeString([], { hour: '2-digit' }),
    val: d.consumption,
    prev: d.consumption * (0.85 + Math.random() * 0.3)
  }));

  const floorStats = Array.from(new Set(data.map(d => d.floor))).map(floor => ({
    name: floor,
    value: data.filter(d => d.floor === floor).reduce((acc, curr) => acc + curr.consumption, 0)
  }));

  const sustainabilityScore = Math.max(0, 100 - (insights.length * 12));

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Network Load', val: '42.8 kWh', delta: '-12%', icon: Zap, color: 'text-primary', bg: 'bg-primary/10' },
          { label: 'Sustainability', val: `${sustainabilityScore}%`, delta: sustainabilityScore > 80 ? 'Optimal' : 'Needs Action', icon: Leaf, color: 'text-emerald-600', bg: 'bg-emerald-50' },
          { label: 'Detected Waste', val: insights.length.toString(), delta: 'Critical', icon: AlertTriangle, color: 'text-red-600', bg: 'bg-red-50' },
          { label: 'Neural Points', val: userPoints.toLocaleString(), delta: 'Top 10%', icon: Award, color: 'text-amber-600', bg: 'bg-amber-50' },
        ].map((stat, i) => (
          <div key={i} className="bg-white dark:bg-slate-900 p-6 rounded-3xl shadow-sm border border-slate-200 dark:border-slate-800 hover:border-primary transition-all group">
            <div className="flex items-start justify-between">
              <div className={`p-3 rounded-2xl ${stat.bg} ${stat.color} group-hover:scale-110 transition-transform`}>
                <stat.icon size={28} />
              </div>
              <span className={`text-[10px] font-black px-3 py-1 rounded-full ${stat.delta === 'Optimal' || stat.delta.startsWith('-') ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'}`}>
                {stat.delta}
              </span>
            </div>
            <h4 className="mt-6 text-slate-500 text-[10px] font-black uppercase tracking-widest">{stat.label}</h4>
            <div className="text-3xl font-black text-slate-900 dark:text-white mt-1">{stat.val}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] shadow-sm border border-slate-200 dark:border-slate-800">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-8 gap-4">
            <div>
              <h3 className="font-black text-2xl tracking-tight">System Flux Analysis</h3>
              <p className="text-xs text-slate-400 font-bold uppercase tracking-[0.2em] mt-1">Real-time Telemetry Patterns</p>
            </div>
            <div className="flex bg-slate-100 dark:bg-slate-800 p-1.5 rounded-2xl border border-slate-200 dark:border-slate-700">
              <button onClick={() => setActiveTab('realtime')} className={`px-6 py-2 text-[10px] font-black uppercase rounded-xl transition-all ${activeTab === 'realtime' ? 'bg-white dark:bg-slate-700 text-primary shadow-sm' : 'text-slate-500'}`}>Realtime</button>
              <button onClick={() => setActiveTab('seasonal')} className={`px-6 py-2 text-[10px] font-black uppercase rounded-xl transition-all ${activeTab === 'seasonal' ? 'bg-white dark:bg-slate-700 text-primary shadow-sm' : 'text-slate-500'}`}>Seasonal</button>
            </div>
          </div>
          <div className="h-[380px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="dashGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="var(--p-color)" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="var(--p-color)" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(148, 163, 184, 0.08)" />
                <XAxis dataKey="time" axisLine={false} tickLine={false} tick={{fontSize: 10, fill: '#94a3b8', fontWeight: 'bold'}} />
                <YAxis axisLine={false} tickLine={false} tick={{fontSize: 10, fill: '#94a3b8', fontWeight: 'bold'}} />
                <Tooltip 
                  contentStyle={{ borderRadius: '24px', border: 'none', boxShadow: '0 25px 50px -12px rgba(0,0,0,0.3)', backgroundColor: '#0f172a', color: 'white' }}
                />
                <Area type="monotone" dataKey="val" name="Actual Load" stroke="var(--p-color)" strokeWidth={4} fill="url(#dashGrad)" />
                <Line type="monotone" dataKey="prev" name="Predicted Baseline" stroke="#64748b" strokeWidth={2} strokeDasharray="5 5" dot={false} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-slate-900 rounded-[2.5rem] p-10 text-white shadow-2xl relative overflow-hidden flex flex-col border border-white/5">
          <div className="absolute -top-10 -right-10 w-48 h-48 bg-primary/20 rounded-full blur-[90px] pointer-events-none" />
          <div className="flex items-center justify-between mb-10 relative z-10">
            <h3 className="font-black text-2xl tracking-tight flex items-center gap-4">
              <div className="w-10 h-10 bg-primary/20 rounded-xl flex items-center justify-center text-primary">
                <Bot size={24} />
              </div>
              Neural Insights
            </h3>
            <span className="text-[10px] font-black bg-white/10 px-4 py-1.5 rounded-full uppercase tracking-widest text-primary border border-white/5">G-3.1 PRO</span>
          </div>
          <div className="space-y-5 flex-1 overflow-y-auto pr-2 custom-scrollbar relative z-10">
            {insights.map((insight) => (
              <div key={insight.id} className="bg-white/5 border border-white/10 p-6 rounded-[2rem] transition-all hover:bg-white/10 group cursor-default hover:border-primary/30">
                <div className="flex justify-between items-start mb-3">
                  <span className="text-[10px] font-black uppercase text-primary tracking-[0.2em]">{insight.category}</span>
                  <span className="text-[11px] font-black bg-primary/20 text-primary px-3 py-1 rounded-full">{insight.impact}</span>
                </div>
                <h4 className="font-bold text-base mb-2 group-hover:text-primary transition-colors tracking-tight">{insight.title}</h4>
                <p className="text-xs text-slate-400 leading-relaxed font-medium">{insight.description}</p>
              </div>
            ))}
          </div>
          <button 
            onClick={onExport}
            className="mt-10 w-full py-5 bg-primary text-white rounded-3xl font-black uppercase tracking-widest text-xs shadow-2xl shadow-primary/40 hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-4 relative z-10"
          >
            <Download size={22} />
            Generate Performance PDF
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm">
           <h3 className="font-black text-[11px] uppercase tracking-[0.3em] text-slate-400 mb-8">Node Inefficiency Distro</h3>
           <div className="h-[280px]">
             <ResponsiveContainer width="100%" height="100%">
               <BarChart data={floorStats}>
                 <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(148, 163, 184, 0.05)" />
                 <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fontSize: 10, fill: '#94a3b8', fontWeight: 'bold'}} />
                 <Tooltip cursor={{fill: 'rgba(59, 130, 246, 0.05)'}} />
                 <Bar dataKey="value" radius={[12, 12, 12, 12]} barSize={28}>
                   {floorStats.map((entry, index) => (
                     <Cell key={`cell-${index}`} fill={index % 2 === 0 ? 'var(--p-color)' : '#10b981'} />
                   ))}
                 </Bar>
               </BarChart>
             </ResponsiveContainer>
           </div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm">
           <div className="flex items-center justify-between mb-8">
             <h3 className="font-black text-2xl tracking-tight flex items-center gap-4">
               <Award size={28} className="text-primary" />
               Champions
             </h3>
             <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest bg-slate-50 dark:bg-slate-800 px-3 py-1 rounded-full">Season 12</span>
           </div>
           <div className="space-y-5">
             {MOCK_LEADERBOARD.map((entry) => (
               <div key={entry.id} className="flex items-center gap-5 p-4 rounded-[1.5rem] hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-all border border-transparent hover:border-slate-100 dark:hover:border-slate-700 group">
                 <div className={`w-12 h-12 rounded-2xl flex items-center justify-center font-black text-base shadow-sm group-hover:scale-110 transition-transform ${
                   entry.rank === 1 ? 'bg-amber-100 text-amber-700' : 
                   entry.rank === 2 ? 'bg-slate-100 text-slate-600' :
                   entry.rank === 3 ? 'bg-orange-100 text-orange-700' : 'bg-primary/10 text-primary'
                 }`}>
                   {entry.rank}
                 </div>
                 <div className="flex-1">
                   <div className="text-base font-black text-slate-800 dark:text-white leading-tight">{entry.name}</div>
                   <div className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-1">Saved: ₹{entry.savings.toLocaleString()}</div>
                 </div>
                 <div className="text-xs font-black text-primary px-4 py-1.5 bg-primary/10 rounded-full">{entry.points.toLocaleString()} XP</div>
               </div>
             ))}
           </div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm">
           <h3 className="font-black text-2xl tracking-tight mb-8 flex items-center gap-4">
             <BarChart4 size={28} className="text-emerald-500" />
             Predictive Health
           </h3>
           <div className="space-y-8">
             <div className="p-6 bg-emerald-50/50 dark:bg-emerald-500/10 rounded-[2rem] border border-emerald-100 dark:border-emerald-500/20 group hover:scale-[1.02] transition-transform">
               <div className="flex justify-between mb-4">
                 <span className="text-sm font-black text-emerald-700 dark:text-emerald-400 uppercase tracking-widest">HVAC Cluster 04</span>
                 <span className="text-xs font-black text-emerald-600">92%</span>
               </div>
               <div className="w-full h-3 bg-emerald-100 dark:bg-slate-800 rounded-full overflow-hidden shadow-inner">
                 <div className="h-full bg-emerald-500 w-[92%] rounded-full shadow-[0_0_15px_rgba(16,185,129,0.5)]" />
               </div>
               <div className="flex items-center gap-2 mt-4 text-[11px] text-emerald-600 dark:text-emerald-400 font-black uppercase tracking-tighter">
                 <CheckCircle2 size={14} /> Pattern Status: Optimal Performance
               </div>
             </div>
             <div className="p-6 bg-red-50/50 dark:bg-red-500/10 rounded-[2rem] border border-red-100 dark:border-red-500/20 group hover:scale-[1.02] transition-transform">
               <div className="flex justify-between mb-4">
                 <span className="text-sm font-black text-red-700 dark:text-red-400 uppercase tracking-widest">Data Server B-12</span>
                 <span className="text-xs font-black text-red-600">38%</span>
               </div>
               <div className="w-full h-3 bg-red-100 dark:bg-slate-800 rounded-full overflow-hidden shadow-inner">
                 <div className="h-full bg-red-500 w-[38%] rounded-full shadow-[0_0_15px_rgba(239,68,68,0.5)]" />
               </div>
               <div className="flex items-center gap-2 mt-4 text-[11px] text-red-600 dark:text-red-400 font-black uppercase tracking-tighter animate-pulse">
                 <AlertTriangle size={14} /> Warning: Thermal Drift Detected
               </div>
             </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
