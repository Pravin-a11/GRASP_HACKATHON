
import React, { useMemo } from 'react';
import { 
  BrainCircuit, Search, Zap, TrendingUp, AlertCircle, 
  CheckCircle2, DollarSign, Activity, Clock, 
  Layers, Filter, Database, ThermometerSnowflake 
} from 'lucide-react';
import { EnergyDataPoint } from '../types';

interface WasteEngineProps {
  data: EnergyDataPoint[];
}

const WasteEngineView: React.FC<WasteEngineProps> = ({ data }) => {
  // Reasoning Logic: Transformation of raw signals into insights
  const detectedAnomalies = useMemo(() => {
    const anomalies: any[] = [];
    
    // 1. RULE: Post-Occupancy Leak (Energy used while occupancy is 0)
    const wastePoints = data.filter(d => d.occupancy === 0 && d.consumption > 15);
    
    if (wastePoints.length > 0) {
      const avgWaste = wastePoints.reduce((a, b) => a + b.consumption, 0) / wastePoints.length;
      anomalies.push({
        id: 'anomaly-1',
        title: 'Post-Occupancy Energy Leak',
        why: `System detected ${wastePoints.length} instances where load (>15kWh) exceeded occupancy (0).`,
        impact: `₹${(avgWaste * 8.5).toFixed(0)}/hr`,
        action: 'Configure HVAC auto-shutdown for Floor 3 at 19:00.',
        confidence: 98,
        type: 'Waste',
        icon: Clock,
        layer: 'Pattern Detection'
      });
    }

    // 2. RULE: Phantom Load (High usage in dead of night)
    const phantomPoints = data.filter(d => {
      const h = new Date(d.timestamp).getHours();
      return (h < 5 || h > 23) && d.consumption > 10;
    });

    if (phantomPoints.length > 0) {
      anomalies.push({
        id: 'anomaly-2',
        title: 'Phantom Baseline Drift',
        why: 'Nightly base load is 12% higher than the learned historical average.',
        impact: '₹180/night',
        action: 'Check secondary server cooling redundant cycles.',
        confidence: 85,
        type: 'Efficiency',
        icon: Zap,
        layer: 'Rule Layer'
      });
    }

    // 3. RULE: Seasonal Baseline Inefficiency
    anomalies.push({
      id: 'anomaly-3',
      title: 'Seasonal Thermal Drift',
      why: 'HVAC runtime coefficient is trending upwards compared to Summer baseline.',
      impact: '₹1,150/month',
      action: 'Perform maintenance on North Wing thermal sensors.',
      confidence: 74,
      type: 'Maintenance',
      icon: ThermometerSnowflake,
      layer: 'Seasonal Learning'
    });

    return anomalies;
  }, [data]);

  const totalLoss = useMemo(() => {
    return detectedAnomalies.reduce((acc, curr) => {
      const val = parseInt(curr.impact.replace(/[^0-9]/g, '')) || 0;
      return acc + val;
    }, 0);
  }, [detectedAnomalies]);

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-8 duration-700">
      {/* 6-Layer Architecture Visualizer */}
      <div className="bg-slate-900 border border-slate-800 rounded-[3rem] p-10 text-white relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 p-12 opacity-[0.02] pointer-events-none">
          <Layers size={400} />
        </div>
        <div className="relative z-10">
          <div className="flex items-center gap-5 mb-12">
            <div className="w-16 h-16 bg-primary rounded-[1.8rem] flex items-center justify-center shadow-2xl shadow-primary/40">
              <BrainCircuit size={36} />
            </div>
            <div>
              <h2 className="text-4xl font-black uppercase tracking-tighter">Neural Waste Engine</h2>
              <div className="flex items-center gap-2 text-[11px] font-black text-primary uppercase tracking-[0.4em] mt-1">
                <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
                Processing 48-Cycle Buffer
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-5">
            {[
              { label: 'Data Input', icon: Database, desc: 'Meter + Occupancy' },
              { label: 'Patterns', icon: Search, desc: 'Behavior Baselines' },
              { label: 'Rule Logic', icon: Filter, desc: 'If/Then Reasoning' },
              { label: 'Impact', icon: DollarSign, desc: 'Cost Calculation' },
              { label: 'Actionable', icon: Zap, desc: 'Targeted Fixes' },
              { label: 'Learning', icon: ThermometerSnowflake, desc: 'Seasonal Drift' }
            ].map((layer, i) => (
              <div key={i} className="bg-white/5 border border-white/10 p-6 rounded-[2rem] group hover:bg-primary/20 hover:border-primary/50 transition-all duration-300">
                <layer.icon size={28} className="text-primary mb-4 group-hover:scale-110 transition-transform" />
                <h4 className="text-[11px] font-black uppercase tracking-widest mb-1">{layer.label}</h4>
                <p className="text-[10px] text-slate-500 font-bold group-hover:text-slate-300 transition-colors leading-tight">{layer.desc}</p>
                <div className="mt-5 h-1.5 w-full bg-white/10 rounded-full overflow-hidden">
                  <div className="h-full bg-primary animate-progress" style={{ width: '100%', animationDelay: `${i * 150}ms` }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] p-10 border border-slate-200 dark:border-slate-800 shadow-sm relative overflow-hidden group">
             <div className="absolute top-0 right-0 p-8 opacity-[0.03] text-red-500 pointer-events-none group-hover:scale-150 transition-transform duration-1000">
               <TrendingUp size={150} />
             </div>
             <h3 className="text-[11px] font-black uppercase tracking-[0.3em] text-slate-400 mb-6 flex items-center gap-2">
               <AlertCircle size={14} className="text-red-500" />
               Recoverable Leakage
             </h3>
             <div className="text-5xl font-black text-slate-900 dark:text-white mb-3 tracking-tighter">₹{totalLoss.toLocaleString()}</div>
             <p className="text-sm font-bold text-slate-500 leading-relaxed italic">Identified as non-justified energy consumption during the current audit cycle.</p>
             <div className="mt-10 pt-8 border-t border-slate-100 dark:border-slate-800">
                <div className="flex justify-between text-[11px] font-black uppercase text-slate-400 mb-3">
                  <span>Engine Confidence</span>
                  <span className="text-primary">94%</span>
                </div>
                <div className="w-full h-2.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full bg-primary rounded-full shadow-[0_0_10px_rgba(59,130,246,0.5)]" style={{ width: '94%' }} />
                </div>
             </div>
          </div>
        </div>

        <div className="lg:col-span-3 space-y-8">
          <div className="flex items-center justify-between">
            <h3 className="text-2xl font-black uppercase tracking-tight flex items-center gap-4 text-slate-800 dark:text-white">
              <Activity className="text-primary" size={28} />
              Neural Reasoning Output
            </h3>
            <div className="px-5 py-2 bg-primary/10 text-primary border border-primary/20 rounded-full text-[10px] font-black uppercase tracking-[0.2em] animate-pulse">
              Engine Live
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {detectedAnomalies.map(finding => (
              <div key={finding.id} className="bg-white dark:bg-slate-900 rounded-[3.5rem] p-10 border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-2xl hover:border-primary/50 transition-all duration-500 group relative overflow-hidden">
                <div className="absolute top-0 right-0 p-10 opacity-[0.03] text-slate-900 dark:text-white pointer-events-none group-hover:scale-125 transition-transform duration-1000">
                  <finding.icon size={150} />
                </div>
                
                <div className="flex justify-between items-start mb-10 relative z-10">
                  <div className="flex items-center gap-5">
                    <div className={`w-16 h-16 rounded-[1.5rem] flex items-center justify-center ${finding.type === 'Waste' ? 'bg-red-500 text-white shadow-red-500/20' : 'bg-primary text-white shadow-primary/20'} shadow-2xl group-hover:rotate-6 transition-transform`}>
                      <finding.icon size={32} />
                    </div>
                    <div>
                      <h4 className="text-xl font-black text-slate-900 dark:text-white tracking-tight">{finding.title}</h4>
                      <div className="flex items-center gap-3 mt-1">
                        <span className="text-[11px] font-black uppercase text-primary tracking-widest">{finding.layer}</span>
                        <div className="w-1.5 h-1.5 bg-slate-200 dark:bg-slate-700 rounded-full" />
                        <span className="text-[11px] font-black uppercase text-slate-400 tracking-widest">Conf: {finding.confidence}%</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-slate-50 dark:bg-slate-800/50 p-8 rounded-[2.5rem] border border-slate-100 dark:border-slate-800 mb-10 relative z-10">
                  <div className="text-[11px] font-black uppercase text-slate-400 mb-3 tracking-[0.2em] flex items-center gap-2">
                    <Search size={14} /> Behavioral Insight
                  </div>
                  <p className="text-base font-bold text-slate-700 dark:text-slate-200 leading-relaxed italic">"{finding.why}"</p>
                </div>

                <div className="flex items-center justify-between relative z-10">
                  <div className="flex items-center gap-5">
                    <div className="w-14 h-14 bg-emerald-500/10 text-emerald-500 rounded-[1.2rem] flex items-center justify-center border border-emerald-500/20 group-hover:scale-110 transition-transform">
                      <CheckCircle2 size={28} />
                    </div>
                    <div>
                      <span className="text-[11px] font-black uppercase text-emerald-500 tracking-widest block mb-1">Recommended Action</span>
                      <p className="text-sm font-bold text-slate-800 dark:text-white leading-tight">{finding.action}</p>
                    </div>
                  </div>
                  <div className="text-right ml-4">
                    <div className="text-3xl font-black text-red-500 tracking-tighter">-{finding.impact}</div>
                    <div className="text-[10px] font-black uppercase text-slate-400 tracking-widest mt-1">Financial Loss</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default WasteEngineView;
