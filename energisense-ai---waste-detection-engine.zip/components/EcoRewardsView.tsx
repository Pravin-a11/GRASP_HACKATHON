
import React, { useState } from 'react';
import { Trophy, Star, Gift, Flame, TrendingDown, Users, ArrowUpRight, Zap, CheckCircle } from 'lucide-react';

interface EcoRewardsProps {
  points: number;
  setPoints: React.Dispatch<React.SetStateAction<number>>;
  onAddNotification: (type: 'info' | 'warning' | 'success', message: string) => void;
}

const EcoRewardsView: React.FC<EcoRewardsProps> = ({ points, setPoints, onAddNotification }) => {
  const rewards = [
    { id: 1, title: 'Carbon Neutral Certificate', cost: 500, icon: Star, color: 'text-amber-500', bg: 'bg-amber-500/10' },
    { id: 2, title: 'Corporate Lounge Pass', cost: 1000, icon: Gift, color: 'text-purple-500', bg: 'bg-purple-500/10' },
    { id: 3, title: 'Priority Parking', cost: 2500, icon: Zap, color: 'text-blue-500', bg: 'bg-blue-500/10' },
    { id: 4, title: 'Neural Pro Badge', cost: 5000, icon: CheckCircle, color: 'text-emerald-500', bg: 'bg-emerald-500/10' },
  ];

  const redeem = (reward: typeof rewards[0]) => {
    if (points >= reward.cost) {
      setPoints(prev => prev - reward.cost);
      onAddNotification('success', `Reward Redeemed: ${reward.title}. Check your terminal messages.`);
      alert(`Redemption Success! ${reward.title} has been credited to your node.`);
    } else {
      onAddNotification('warning', `Insufficient XP for ${reward.title}.`);
      alert(`Neural points mismatch. You need ${reward.cost - points} more XP.`);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-6 duration-700">
      <div className="bg-slate-900 rounded-[3.5rem] p-12 text-white shadow-2xl relative overflow-hidden border border-white/5">
        <div className="absolute top-0 right-0 p-12 opacity-[0.03] pointer-events-none">
          <Trophy size={320} />
        </div>
        <div className="relative z-10 flex flex-col lg:flex-row justify-between items-center gap-12">
          <div>
            <div className="flex items-center gap-5 mb-6">
              <div className="p-4 bg-primary rounded-3xl shadow-2xl shadow-primary/20">
                <Trophy size={42} className="text-white" />
              </div>
              <div>
                <h2 className="text-4xl font-black uppercase tracking-tighter">Eco-Champions Portal</h2>
                <div className="text-[10px] font-black uppercase tracking-[0.3em] text-primary mt-1">Sustainability Gamification Tier 4</div>
              </div>
            </div>
            <p className="text-slate-400 max-w-lg text-lg font-medium leading-relaxed">Your sustainability actions fuel the building's neural health. Earn XP by responding to AI alerts and eliminating phantom loads.</p>
          </div>
          <div className="text-center bg-white/5 border border-white/10 p-10 rounded-[3rem] min-w-[280px] backdrop-blur-3xl shadow-inner relative overflow-hidden group">
            <div className="absolute -inset-1 bg-gradient-to-r from-primary/20 to-emerald-500/20 opacity-0 group-hover:opacity-100 transition-opacity blur-2xl" />
            <div className="relative z-10">
              <div className="text-primary text-6xl font-black mb-2 tracking-tighter animate-pulse">{points}</div>
              <div className="text-[11px] font-black uppercase tracking-[0.2em] text-slate-500">Neural XP Balance</div>
              <div className="mt-6 w-full h-2 bg-white/10 rounded-full overflow-hidden">
                <div className="h-full bg-primary transition-all duration-1000" style={{ width: `${(points % 1000) / 10}%` }} />
              </div>
              <div className="mt-2 text-[10px] font-bold text-slate-600 uppercase">Next Tier: {1000 - (points % 1000)} XP Remaining</div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <h3 className="text-2xl font-black uppercase tracking-tight flex items-center gap-4 text-slate-800 dark:text-white">
            <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center text-primary">
              <Gift size={24} />
            </div>
            Neural Marketplace
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {rewards.map(reward => (
              <div key={reward.id} className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm flex items-center justify-between group hover:border-primary transition-all hover:shadow-2xl hover:shadow-primary/5">
                <div className="flex items-center gap-5">
                  <div className={`p-5 rounded-[1.5rem] ${reward.bg} ${reward.color} group-hover:scale-110 transition-transform`}>
                    <reward.icon size={28} />
                  </div>
                  <div>
                    <h4 className="font-black text-slate-900 dark:text-white group-hover:text-primary transition-colors">{reward.title}</h4>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-sm font-black text-primary">{reward.cost.toLocaleString()} XP</span>
                      <div className="w-1 h-1 rounded-full bg-slate-300 dark:bg-slate-700" />
                      <span className="text-[10px] font-bold text-slate-400 uppercase">One-time redeem</span>
                    </div>
                  </div>
                </div>
                <button 
                  onClick={() => redeem(reward)}
                  className="p-4 bg-slate-900 dark:bg-slate-800 text-white rounded-2xl hover:bg-primary transition-all shadow-xl active:scale-90"
                >
                  <ArrowUpRight size={22} />
                </button>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-8">
          <h3 className="text-2xl font-black uppercase tracking-tight flex items-center gap-4 text-slate-800 dark:text-white">
            <div className="w-10 h-10 bg-orange-500/10 rounded-xl flex items-center justify-center text-orange-500">
              <Flame size={24} />
            </div>
            Performance Streak
          </h3>
          <div className="bg-white dark:bg-slate-900 p-10 rounded-[3rem] border border-slate-200 dark:border-slate-800 shadow-sm relative overflow-hidden">
             <div className="flex items-center justify-between mb-10 relative z-10">
                <div>
                  <div className="text-5xl font-black text-orange-500 tracking-tighter">12 Days</div>
                  <div className="text-[11px] font-black uppercase tracking-[0.2em] text-slate-400 mt-1">Neural Uptime Streak</div>
                </div>
                <div className="p-4 bg-emerald-50 dark:bg-emerald-500/10 rounded-full text-emerald-500 shadow-inner">
                  <TrendingDown size={44} />
                </div>
             </div>
             <div className="space-y-6 relative z-10">
                <div className="flex items-center gap-5 group">
                  <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 text-emerald-500 flex items-center justify-center font-black text-sm border border-emerald-500/20 group-hover:scale-110 transition-transform">✓</div>
                  <div>
                    <span className="text-sm font-black text-slate-700 dark:text-slate-300 block">Phantom Load Erased</span>
                    <span className="text-[10px] font-bold text-slate-400 uppercase">2h ago • Floor 3 Node</span>
                  </div>
                </div>
                <div className="flex items-center gap-5 group">
                  <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 text-emerald-500 flex items-center justify-center font-black text-sm border border-emerald-500/20 group-hover:scale-110 transition-transform">✓</div>
                  <div>
                    <span className="text-sm font-black text-slate-700 dark:text-slate-300 block">HVAC Threshold Sync</span>
                    <span className="text-[10px] font-bold text-slate-400 uppercase">Yesterday • Main Lab</span>
                  </div>
                </div>
             </div>
             <div className="mt-10 pt-8 border-t border-slate-100 dark:border-slate-800">
               <div className="flex justify-between text-[11px] font-black uppercase text-slate-400 mb-3">
                 <span>Weekly Efficiency Target</span>
                 <span className="text-primary">88%</span>
               </div>
               <div className="w-full h-2.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden shadow-inner">
                 <div className="h-full bg-primary rounded-full shadow-[0_0_15px_rgba(59,130,246,0.5)]" style={{ width: '88%' }} />
               </div>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EcoRewardsView;
