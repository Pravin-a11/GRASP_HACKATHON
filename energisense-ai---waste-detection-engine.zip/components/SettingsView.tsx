
import React, { useState } from 'react';
import { Save, Building2, BellRing, Gauge, Globe, RefreshCcw, ShieldCheck, MapPin } from 'lucide-react';

const SettingsView: React.FC = () => {
  const [settings, setSettings] = useState({
    buildingName: localStorage.getItem('cfg_building_name') || 'Main Corporate HQ',
    currency: localStorage.getItem('cfg_currency') || '₹',
    costPerKwh: localStorage.getItem('cfg_cost_kwh') || '8.50',
    alertThreshold: localStorage.getItem('cfg_threshold') || '400',
    region: localStorage.getItem('cfg_region') || 'South Asia'
  });

  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved'>('idle');

  const handleSave = () => {
    setSaveStatus('saving');
    setTimeout(() => {
      localStorage.setItem('cfg_building_name', settings.buildingName);
      localStorage.setItem('cfg_currency', settings.currency);
      localStorage.setItem('cfg_cost_kwh', settings.costPerKwh);
      localStorage.setItem('cfg_threshold', settings.alertThreshold);
      localStorage.setItem('cfg_region', settings.region);
      setSaveStatus('saved');
      setTimeout(() => setSaveStatus('idle'), 3000);
    }, 1200);
  };

  const regions = ['South Asia', 'North America', 'Europe Central', 'APAC North', 'Middle East'];

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-black tracking-tight">System Core Preferences</h2>
          <p className="text-slate-500 dark:text-slate-400 font-medium mt-1">Configuration parameters for the global neural network.</p>
        </div>
        {saveStatus === 'saved' && (
          <div className="flex items-center gap-2 text-emerald-500 text-xs font-black bg-emerald-50 dark:bg-emerald-500/10 px-6 py-3 rounded-full border border-emerald-100 dark:border-emerald-500/20 uppercase tracking-widest">
            <ShieldCheck size={18} /> Protocol Updated
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm space-y-8">
          <div className="flex items-center gap-3">
            <Building2 className="text-primary" size={24} />
            <h3 className="font-black text-lg">Building Metadata</h3>
          </div>
          
          <div className="space-y-6">
            <div>
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2 ml-1">Terminal Handle</label>
              <input 
                type="text" 
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl p-4 text-sm font-bold focus:ring-4 focus:ring-primary/10 outline-none transition-all"
                value={settings.buildingName}
                onChange={e => setSettings({...settings, buildingName: e.target.value})}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2 ml-1">Market Region</label>
                <select 
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl p-4 text-sm font-bold outline-none cursor-pointer hover:border-primary transition-colors"
                  value={settings.region}
                  onChange={e => setSettings({...settings, region: e.target.value})}
                >
                  {regions.map(r => <option key={r} value={r}>{r}</option>)}
                </select>
              </div>
              <div>
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2 ml-1">Metric Currency</label>
                <select 
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl p-4 text-sm font-bold outline-none cursor-pointer hover:border-primary transition-colors"
                  value={settings.currency}
                  onChange={e => setSettings({...settings, currency: e.target.value})}
                >
                  <option value="₹">Rupee (₹)</option>
                  <option value="$">US Dollar ($)</option>
                  <option value="€">Euro (€)</option>
                  <option value="£">Pound (£)</option>
                </select>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm space-y-8">
          <div className="flex items-center gap-3">
            <Gauge className="text-amber-500" size={24} />
            <h3 className="font-black text-lg">Alert Sensitivity</h3>
          </div>

          <div className="space-y-6">
            <div>
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2 ml-1">Unit Tariff ({settings.currency}/kWh)</label>
              <input 
                type="number" 
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl p-4 text-sm font-bold outline-none focus:ring-4 focus:ring-primary/10 transition-all"
                value={settings.costPerKwh}
                onChange={e => setSettings({...settings, costPerKwh: e.target.value})}
              />
            </div>

            <div>
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2 ml-1">Anomaly Floor (Daily {settings.currency})</label>
              <input 
                type="number" 
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl p-4 text-sm font-bold outline-none focus:ring-4 focus:ring-primary/10 transition-all"
                value={settings.alertThreshold}
                onChange={e => setSettings({...settings, alertThreshold: e.target.value})}
              />
            </div>
          </div>
        </div>
      </div>

      <div className="bg-slate-900 rounded-[3rem] p-10 text-white border border-slate-800 flex flex-col md:flex-row items-center justify-between gap-8 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full opacity-5 pointer-events-none">
          <MapPin size={400} className="absolute -left-20 -top-20" />
        </div>
        <div className="flex items-center gap-6 relative z-10">
          <div className="p-5 bg-primary/20 rounded-3xl text-primary border border-primary/20 shadow-xl">
            <RefreshCcw size={32} className={saveStatus === 'saving' ? 'animate-spin' : ''} />
          </div>
          <div>
            <h4 className="text-xl font-black tracking-tight">Synchronize State</h4>
            <p className="text-slate-400 text-sm font-medium mt-1">Commit system-wide changes to the neural engine.</p>
          </div>
        </div>
        <div className="flex gap-4 relative z-10">
          <button 
            onClick={() => window.location.reload()}
            className="px-8 py-4 border border-slate-700 text-slate-300 rounded-2xl font-black uppercase tracking-widest text-xs hover:bg-slate-800 transition-all"
          >
            Revert
          </button>
          <button 
            onClick={handleSave}
            disabled={saveStatus === 'saving'}
            className="flex items-center gap-3 px-12 py-4 bg-primary text-white rounded-2xl font-black uppercase tracking-widest text-xs shadow-2xl shadow-primary/40 hover:scale-[1.02] active:scale-95 transition-all disabled:opacity-50"
          >
            {saveStatus === 'saving' ? 'Processing...' : 'Commit Configuration'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default SettingsView;
