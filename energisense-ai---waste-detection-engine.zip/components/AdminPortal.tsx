
import React, { useState } from 'react';
import { Plus, Upload, Database, Save, Terminal, Activity, Trash2, ShieldCheck } from 'lucide-react';
import { EnergyDataPoint } from '../types';

interface AdminPortalProps {
  data: EnergyDataPoint[];
  onAddData: (newData: EnergyDataPoint[]) => void;
}

const AdminPortal: React.FC<AdminPortalProps> = ({ data, onAddData }) => {
  const [newPoint, setNewPoint] = useState<Partial<EnergyDataPoint>>({
    floor: 'Floor 1',
    type: 'HVAC',
    consumption: 0,
    occupancy: 1
  });

  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [terminalLogs, setTerminalLogs] = useState<string[]>(['[BOOT] Neural Ingestion Core Online...']);

  const handleManualAdd = () => {
    const point: EnergyDataPoint = {
      timestamp: new Date().toISOString(),
      consumption: Number(newPoint.consumption) || 0,
      occupancy: newPoint.occupancy as number,
      floor: newPoint.floor || 'Floor 1',
      type: newPoint.type as any || 'HVAC'
    };
    onAddData([point]);
    setTerminalLogs(prev => [`[INFO] Manual Signal: Node_${point.floor} -> ${point.consumption}kWh`, ...prev.slice(0, 10)]);
  };

  const generateExtremeData = () => {
    setIsProcessing(true);
    setProgress(0);
    setTerminalLogs(prev => ['[STRESS] Initializing 10,000 Signal Batch Ingestion...', ...prev]);
    
    let current = 0;
    const interval = setInterval(() => {
      current += 1;
      setProgress(current);
      
      if (current % 10 === 0) {
        setTerminalLogs(prev => [`[PROCESS] Buffer Segment ${current/10}% Allocated...`, ...prev.slice(0, 12)]);
      }

      if (current >= 100) {
        clearInterval(interval);
        setIsProcessing(false);
        
        // Generate massive data payload: 10,000 points
        const payload: EnergyDataPoint[] = Array.from({ length: 10000 }).map(() => ({
          timestamp: new Date(Date.now() - Math.random() * 1.2e9).toISOString(),
          consumption: Math.random() * 150 + 2,
          occupancy: Math.random() > 0.4 ? 1 : 0,
          floor: `Node_${Math.floor(Math.random() * 15) + 1}`,
          type: ['HVAC', 'Lighting', 'Equipment', 'Phantom'][Math.floor(Math.random() * 4)] as any
        }));
        
        onAddData(payload);
        setTerminalLogs(prev => ['[DONE] 10,000 Signals successfully committed to neural database.', ...prev]);
      }
    }, 30);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Laboratory Control</h2>
          <p className="text-slate-500 dark:text-slate-400">High-frequency signal ingestion and building topology mapping.</p>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={generateExtremeData}
            disabled={isProcessing}
            className={`flex items-center gap-2 px-6 py-3 bg-slate-900 dark:bg-slate-700 text-white rounded-xl transition-all shadow-xl hover:scale-105 active:scale-95 disabled:opacity-50`}
          >
            <Upload size={18} />
            Ingest 10,000 Signals
          </button>
        </div>
      </div>

      {isProcessing && (
        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-primary/30 shadow-2xl animate-in zoom-in duration-300">
          <div className="flex justify-between mb-2">
            <span className="text-xs font-bold text-primary uppercase flex items-center gap-2 animate-pulse">
              <Activity size={14} /> Parallel Threading Active
            </span>
            <span className="text-sm font-black text-slate-900 dark:text-white">{progress}%</span>
          </div>
          <div className="w-full h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
            <div className="h-full bg-primary transition-all duration-300" style={{ width: `${progress}%` }} />
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        <div className="xl:col-span-2 space-y-6">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
            <div className="p-4 bg-slate-50 dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 flex justify-between items-center">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-slate-500">
                <Database size={16} className="text-primary" /> Active Repository
              </div>
              <span className="px-3 py-1 bg-primary text-white text-[10px] font-black rounded-full">
                {data.length.toLocaleString()} SIGNALS ONLINE
              </span>
            </div>
            <div className="h-[450px] overflow-y-auto">
              <table className="w-full text-left text-xs">
                <thead className="sticky top-0 bg-slate-50 dark:bg-slate-800 font-bold uppercase text-slate-400">
                  <tr>
                    <th className="px-6 py-4">Ref ID</th>
                    <th className="px-6 py-4">Floor / Topology</th>
                    <th className="px-6 py-4">Stream Value</th>
                    <th className="px-6 py-4 text-right">State</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-mono">
                  {data.slice(-50).reverse().map((point, i) => (
                    <tr key={i} className="hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors">
                      <td className="px-6 py-3 text-slate-400 uppercase tracking-tighter">SIG-{Math.floor(Math.random()*1e6)}</td>
                      <td className="px-6 py-3 font-bold">{point.floor} / {point.type}</td>
                      <td className="px-6 py-3 text-primary font-bold">{point.consumption.toFixed(3)} kWh</td>
                      <td className="px-6 py-3 text-right">
                        <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block shadow-lg" />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="bg-slate-950 rounded-2xl p-4 font-mono text-[11px] text-emerald-400 h-40 overflow-y-auto shadow-inner border border-slate-800">
            <div className="flex items-center gap-2 mb-2 text-slate-600 uppercase font-black sticky top-0 bg-slate-950 pb-2 border-b border-slate-800">
              <Terminal size={14} /> Core IO Logs
            </div>
            {terminalLogs.map((log, i) => (
              <div key={i} className="mb-1">{log}</div>
            ))}
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm">
            <h3 className="font-bold mb-6 flex items-center gap-2 uppercase tracking-widest text-xs text-slate-400">
              <Plus size={18} className="text-primary" /> Single Injection
            </h3>
            <div className="space-y-4">
              <div>
                <label className="text-[10px] font-black text-slate-400 uppercase block mb-1">Target Zone</label>
                <select 
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-4 text-sm outline-none"
                  value={newPoint.floor}
                  onChange={(e) => setNewPoint({...newPoint, floor: e.target.value})}
                >
                   {Array.from({length: 15}).map((_, i) => (
                    <option key={i} value={`Node_${i+1}`}>Node Segment {i+1}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-[10px] font-black text-slate-400 uppercase block mb-1">Consumption Magnitude</label>
                <input 
                  type="number" 
                  step="0.01"
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-4 text-sm outline-none focus:ring-2 focus:ring-primary/20"
                  value={newPoint.consumption}
                  onChange={(e) => setNewPoint({...newPoint, consumption: Number(e.target.value)})}
                />
              </div>
              <button 
                onClick={handleManualAdd}
                className="w-full py-4 bg-primary text-white rounded-xl font-bold hover:scale-[1.02] active:scale-95 transition-all shadow-lg flex items-center justify-center gap-2"
              >
                <Save size={18} />
                Inject Signal
              </button>
            </div>
          </div>

          <div className="bg-gradient-to-br from-slate-900 to-black text-white rounded-3xl p-8 relative overflow-hidden shadow-2xl border border-slate-800">
             <div className="absolute -top-4 -right-4 p-8 opacity-10">
               <ShieldCheck size={120} />
             </div>
             <h3 className="text-xs font-black uppercase tracking-[0.2em] text-primary mb-2">Security Status</h3>
             <div className="text-2xl font-bold mb-4 tracking-tight">V3 Integrity Verified</div>
             <div className="space-y-4 text-sm text-slate-400 relative z-10">
               <div className="flex justify-between">
                 <span>Latency</span>
                 <span className="text-emerald-400 font-mono">12ms</span>
               </div>
               <div className="flex justify-between">
                 <span>Packets Drop</span>
                 <span className="text-emerald-400 font-mono">0.00%</span>
               </div>
             </div>
             <button className="mt-8 w-full py-2 border border-slate-700 rounded-xl text-xs font-bold hover:bg-white/5 transition-all">Perform Full System Audit</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminPortal;
