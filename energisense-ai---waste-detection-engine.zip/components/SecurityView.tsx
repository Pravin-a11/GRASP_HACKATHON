
import React from 'react';
import { ShieldCheck, Lock, Eye, Key, Activity, Server } from 'lucide-react';

const SecurityView: React.FC = () => {
  const logs = [
    { time: '14:20:05', user: 'Admin_Miller', action: 'Signal Ingress Injected', status: 'Verified', ip: '192.168.1.42' },
    { time: '13:45:12', user: 'Floor_Mgr_3', action: 'Dashboard Sync', status: 'Authorized', ip: '10.0.0.12' },
    { time: '12:02:44', user: 'Neural_Core', action: 'Weight Re-calibration', status: 'Success', ip: 'Internal' },
    { time: '11:15:30', user: 'Admin_Miller', action: 'Protocol Update', status: 'Success', ip: '192.168.1.42' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-black">Security Infrastructure</h2>
          <p className="text-slate-500 dark:text-slate-400 text-sm font-medium uppercase tracking-widest text-[10px] mt-1">AES-256 E2EE Enabled</p>
        </div>
        <div className="flex gap-2">
          <span className="flex items-center gap-2 text-xs font-black text-emerald-600 bg-emerald-50 dark:bg-emerald-500/10 px-5 py-2 rounded-full border border-emerald-100 dark:border-emerald-500/20">
            <ShieldCheck size={16} /> SYSTEM SECURE
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[
          { icon: Lock, title: 'Network Encryption', desc: 'All telemetry packets are signed with RSA-4096 before transmission.', color: 'text-primary' },
          { icon: Key, title: 'Access Control', desc: 'Hardware-based MFA enforced for all administrative terminal sessions.', color: 'text-amber-500' },
          { icon: Activity, title: 'Flux Monitoring', desc: 'Zero data drift detected in cross-node neural verification logs.', color: 'text-indigo-500' },
        ].map((item, idx) => (
          <div key={idx} className="bg-white dark:bg-slate-900 p-8 rounded-[2rem] border border-slate-200 dark:border-slate-800 shadow-sm group hover:border-primary transition-all">
            <item.icon className={`${item.color} mb-6 group-hover:scale-110 transition-transform`} size={32} />
            <h3 className="font-black text-slate-900 dark:text-white mb-2">{item.title}</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 font-medium leading-relaxed">{item.desc}</p>
          </div>
        ))}
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-[2rem] border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
        <div className="p-6 bg-slate-50 dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Eye size={20} className="text-slate-400" />
            <span className="font-black text-xs uppercase tracking-widest text-slate-800 dark:text-white">Neural Audit Ledger</span>
          </div>
          <span className="text-[10px] font-black text-primary bg-primary/10 px-3 py-1 rounded-full animate-pulse">MONITORING ACTIVE</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-200 uppercase text-[10px] font-black tracking-[0.2em] border-b border-slate-200 dark:border-slate-700">
              <tr>
                <th className="px-8 py-5">Timestamp (UTC)</th>
                <th className="px-8 py-5">Neural Identity</th>
                <th className="px-8 py-5">Operation Vector</th>
                <th className="px-8 py-5">Integrity</th>
                <th className="px-8 py-5 text-right">Source Cluster</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
              {logs.map((log, i) => (
                <tr key={i} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors group">
                  <td className="px-8 py-5 font-mono text-xs text-slate-900 dark:text-white font-bold">{log.time}</td>
                  <td className="px-8 py-5 text-slate-900 dark:text-white font-black">{log.user}</td>
                  <td className="px-8 py-5 text-slate-600 dark:text-slate-400 group-hover:text-primary transition-colors">{log.action}</td>
                  <td className="px-8 py-5">
                    <span className="px-3 py-1 rounded-full bg-emerald-100 dark:bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 text-[10px] font-black uppercase tracking-widest">
                      {log.status}
                    </span>
                  </td>
                  <td className="px-8 py-5 text-slate-500 dark:text-slate-500 font-mono text-xs text-right group-hover:text-slate-900 dark:group-hover:text-white transition-colors">{log.ip}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default SecurityView;
