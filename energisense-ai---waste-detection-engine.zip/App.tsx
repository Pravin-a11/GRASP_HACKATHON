
import React, { useState, useEffect, useCallback } from 'react';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import AdminPortal from './components/AdminPortal';
import ChatInterface from './components/ChatInterface';
import SecurityView from './components/SecurityView';
import AnalyticsView from './components/AnalyticsView';
import SettingsView from './components/SettingsView';
import LoginView from './components/LoginView';
import EcoRewardsView from './components/EcoRewardsView';
import WasteEngineView from './components/WasteEngineView';
import { UserRole, EnergyDataPoint, Insight } from './types';
import { MOCK_ENERGY_DATA, INITIAL_INSIGHTS } from './constants';
import { analyzeEnergyPatterns } from './services/geminiService';
import { Bot, Bell, Palette, Moon, Sun, X, CheckCircle, AlertTriangle, Info, LogOut, Smartphone } from 'lucide-react';

interface Notification {
  id: string;
  type: 'info' | 'warning' | 'success';
  message: string;
  time: string;
}

const App: React.FC = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(localStorage.getItem('is_logged_in') === 'true');
  const [role, setRole] = useState<UserRole>(localStorage.getItem('user_role') as UserRole || UserRole.ADMIN);
  const [activeView, setActiveView] = useState('dashboard');
  const [energyData, setEnergyData] = useState<EnergyDataPoint[]>(MOCK_ENERGY_DATA);
  const [insights, setInsights] = useState<Insight[]>(INITIAL_INSIGHTS);
  const [userPoints, setUserPoints] = useState(Number(localStorage.getItem('user_points')) || 1250);
  
  const [isAiDrawerOpen, setIsAiDrawerOpen] = useState(false);
  const [isThemePanelOpen, setIsThemePanelOpen] = useState(false);
  const [themeColor, setThemeColor] = useState(localStorage.getItem('theme_color') || '#3b82f6');
  const [isDarkMode, setIsDarkMode] = useState(localStorage.getItem('is_dark_mode') === 'true');
  
  const [notifications, setNotifications] = useState<Notification[]>([
    { id: '1', type: 'warning', message: 'Floor 3 HVAC Leak Detected', time: '2m ago' },
    { id: '2', type: 'success', message: 'Cluster Alpha Optimized', time: '1h ago' },
    { id: '3', type: 'info', message: 'Monthly report ready for export', time: '3h ago' },
  ]);
  const [isNotifOpen, setIsNotifOpen] = useState(false);

  // OPTIMIZATION: Update CSS variables directly for instant theme response
  // We apply changes directly to the root for performance
  useEffect(() => {
    document.documentElement.style.setProperty('--p-color', themeColor);
    localStorage.setItem('theme_color', themeColor);
  }, [themeColor]);

  useEffect(() => {
    if (isDarkMode) document.documentElement.classList.add('dark');
    else document.documentElement.classList.remove('dark');
    localStorage.setItem('is_dark_mode', isDarkMode.toString());
  }, [isDarkMode]);

  useEffect(() => {
    localStorage.setItem('user_points', userPoints.toString());
  }, [userPoints]);

  const addNotification = useCallback((type: 'info' | 'warning' | 'success', message: string) => {
    const newNotif: Notification = {
      id: Date.now().toString(),
      type,
      message,
      time: 'Just now'
    };
    setNotifications(prev => [newNotif, ...prev.slice(0, 10)]);
  }, []);

  const handleLogin = (selectedRole: UserRole) => {
    setRole(selectedRole);
    setIsLoggedIn(true);
    localStorage.setItem('is_logged_in', 'true');
    localStorage.setItem('user_role', selectedRole);
    addNotification('info', `Authentication Successful: ${selectedRole} Role Granted`);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    localStorage.removeItem('is_logged_in');
    setActiveView('dashboard');
    setIsAiDrawerOpen(false);
    setIsThemePanelOpen(false);
  };

  const handleAddData = (newData: EnergyDataPoint[]) => {
    setEnergyData(prev => [...prev, ...newData]);
    addNotification('success', `Neural Ingress: Processed ${newData.length.toLocaleString()} signals`);
  };

  const colors = [
    { name: 'Classic Blue', value: '#3b82f6' },
    { name: 'Emerald', value: '#10b981' },
    { name: 'Amber', value: '#f59e0b' },
    { name: 'Rose', value: '#ef4444' },
    { name: 'Indigo', value: '#6366f1' },
    { name: 'Purple', value: '#8b5cf6' },
  ];

  if (!isLoggedIn) {
    return <LoginView onLogin={handleLogin} />;
  }

  return (
    <div className="flex h-screen bg-slate-50 dark:bg-slate-950 overflow-hidden text-slate-900 dark:text-slate-100 font-sans transition-colors duration-150">
      <Sidebar 
        currentRole={role} 
        onNavigate={setActiveView} 
        onLogout={handleLogout}
        activeView={activeView} 
      />

      <main className="flex-1 flex flex-col min-w-0 h-full overflow-hidden relative no-print transition-all duration-300">
        <header className="h-16 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 flex items-center justify-between px-6 shrink-0 z-10 no-print">
          <div className="flex items-center gap-4">
            <h1 className="text-lg font-bold capitalize tracking-tight">{activeView.replace('-', ' ')}</h1>
            <div className="h-4 w-px bg-slate-200 dark:bg-slate-700" />
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-black uppercase bg-primary/10 text-primary px-3 py-1 rounded-full tracking-widest">
                {role} ACCESS
              </span>
              <span className="text-[10px] font-black uppercase bg-amber-500/10 text-amber-500 px-3 py-1 rounded-full tracking-widest">
                {userPoints} XP
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="relative">
              <button 
                onClick={() => setIsNotifOpen(!isNotifOpen)}
                className="p-2 text-slate-400 hover:text-primary transition-colors relative"
              >
                <Bell size={20} />
                {notifications.length > 0 && (
                  <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-white dark:border-slate-900 shadow-sm" />
                )}
              </button>
              
              {isNotifOpen && (
                <div className="absolute right-0 mt-3 w-85 bg-white dark:bg-slate-800 rounded-3xl shadow-[0_20px_70px_-15px_rgba(0,0,0,0.3)] border border-slate-200 dark:border-slate-700 p-5 z-[200] animate-notification">
                  <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100 dark:border-slate-700">
                    <h3 className="font-black text-[10px] uppercase tracking-[0.2em] text-slate-400">Live Logs</h3>
                    <button onClick={() => setIsNotifOpen(false)} className="text-slate-400 hover:text-slate-900 dark:hover:text-white transition-colors"><X size={16} /></button>
                  </div>
                  <div className="space-y-3 max-h-[450px] overflow-y-auto pr-2 custom-scrollbar">
                    {notifications.map(n => (
                      <div key={n.id} className="flex gap-4 p-4 rounded-2xl hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-all group cursor-pointer border border-transparent hover:border-slate-100 dark:hover:border-slate-700">
                        <div className={`mt-0.5