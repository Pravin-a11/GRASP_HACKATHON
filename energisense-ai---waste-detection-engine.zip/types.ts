
export enum UserRole {
  ADMIN = 'ADMIN',
  USER = 'USER'
}

export interface EnergyDataPoint {
  timestamp: string;
  consumption: number; // in kWh
  occupancy: number; // 0 or 1
  floor: string;
  type: 'HVAC' | 'Lighting' | 'Equipment' | 'Phantom';
}

export interface Insight {
  id: string;
  title: string;
  description: string;
  impact: string; // e.g., "₹400/day"
  priority: 'High' | 'Medium' | 'Low';
  category: 'Efficiency' | 'Waste' | 'Maintenance';
  timestamp: string;
  estimatedSaving?: number;
}

export interface LeaderboardEntry {
  id: string;
  name: string;
  points: number;
  rank: number;
  savings: number;
}

export interface AppState {
  role: UserRole;
  theme: string;
  energyData: EnergyDataPoint[];
  insights: Insight[];
  points: number;
}
