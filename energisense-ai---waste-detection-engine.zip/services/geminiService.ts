
import { GoogleGenAI, Type } from "@google/genai";
import { EnergyDataPoint, Insight } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function analyzeEnergyPatterns(data: EnergyDataPoint[]): Promise<Insight[]> {
  try {
    const prompt = `
      You are the EnergiSense AI Reasoning Engine. 
      Analyze the building usage patterns strictly using this 6-layer architecture:
      
      1. DATA CONTEXT: Combine kWh usage per floor/zone with occupancy schedules.
      2. PATTERN DETECTION: Identify typical behavior vs anomalies (AC on when occupancy=0).
      3. REASONING RULES: 
         - Rule A: If energy usage > baseline after occupancy ends -> flag waste.
         - Rule B: If weekend usage > weekday baseline -> investigate.
         - Rule C: If HVAC runtime > seasonal average -> inefficiency alert.
      4. COST IMPACT: Convert extra kWh into monetary loss (₹8.50 per kWh).
      5. ACTIONABLE GENERATION: Provide simple fixing suggestions (automation, maintenance).
      6. SEASONAL LEARNING: Adjust expectations based on current climate (Summer/Winter).

      Data snapshot (Last 48 cycles):
      ${JSON.stringify(data.slice(-48))}

      Output clear, high-impact insights in JSON format.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              description: { type: Type.STRING },
              impact: { type: Type.STRING },
              priority: { type: Type.STRING, enum: ['High', 'Medium', 'Low'] },
              category: { type: Type.STRING, enum: ['Efficiency', 'Waste', 'Maintenance'] },
              estimatedSaving: { type: Type.NUMBER, description: "Monthly saving in local currency" }
            },
            required: ['title', 'description', 'impact', 'priority', 'category', 'estimatedSaving'],
          }
        }
      }
    });

    const insights = JSON.parse(response.text || "[]");
    return insights.map((insight: any) => ({
      ...insight,
      id: Math.random().toString(36).substr(2, 9),
      timestamp: new Date().toISOString(),
    }));
  } catch (error) {
    console.error("AI Analysis failed:", error);
    return [];
  }
}

export async function chatWithEnergyAdvisor(query: string, data: EnergyDataPoint[]) {
  const prompt = `
    You are the EnergiSense Neural Advisor. 
    You transform raw graphs into actionable monetary insights based on the Rule+ML Engine logic:
    - DATA: Occupancy + Time Context.
    - REASONING: usage > baseline during 0 occupancy = Waste.
    - OUTPUT: Cost Impact (₹) + Suggested Action.

    User Question: "${query}"
    Data context: Avg usage ${(data.reduce((a, b) => a + b.consumption, 0) / data.length).toFixed(2)} kWh.
    
    Be direct, point out specific money loss, and tell them exactly how to fix it.
  `;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
  });

  return response.text;
}
